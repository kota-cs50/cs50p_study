x = int(input("what's x ? "))
y = int(input("what's y ? "))

if x == y:
    print("x is equal to y")
else:
    print("x is not equal to y")

"""
if x < y:
    print("x is less then y")
elif x > y: #elifとは、ifの条件が違ったとき作る条件で、ifと違い条件が合っていればそこで処理を終了してくれること。（無駄がないこと）
    print("x is greater than y")
else:#elseは上の条件以外の条件という意味であるので、条件が残り一つというきめられている場合にコードを短縮して書ける
    print("x is equal to y")
"""

