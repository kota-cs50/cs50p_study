character = str(input()).lower()
print(character)
