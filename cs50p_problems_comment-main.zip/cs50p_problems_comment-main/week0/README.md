＜indoor.py＞
strのメソッドの確認

＜playback.py＞
strメソッドの確認

＜faces.py＞
return関数の使い方
strメソッドの確認

＜einstein.py＞
pow関数の確認

＜tip.py＞
少数の数字の表示の仕方
return関数の使い方
