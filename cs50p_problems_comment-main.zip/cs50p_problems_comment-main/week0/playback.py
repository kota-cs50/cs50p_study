character = str(input("")).replace(" ", "...")
print(character)
