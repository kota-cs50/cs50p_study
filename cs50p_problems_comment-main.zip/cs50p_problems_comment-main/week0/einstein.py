m = int(input())
E = m * pow(300000000, 2)

print(E)

